#ifndef BUFFER_H
#define BUFFER_H

#define BS 256

int read_buffer(char *c);
void write_buffer(char c);

#endif  /* BUFFER_H */
